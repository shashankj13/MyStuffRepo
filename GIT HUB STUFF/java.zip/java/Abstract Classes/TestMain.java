class TestMain{
	public static void main(String...args){
		Sedan s=new Sedan();
		s.ignition();
		s.changeGear();
		System.out.println(s.noOfWheels);
	}
	
}