abstract public class Car{
	int noOfWheels=4;
	abstract void ignition();
	public void changeGear(){
		System.out.println("Gear Changed");
		
	}
	
}

