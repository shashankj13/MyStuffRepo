class Sedan extends Car{
	void ignition()
	{
		System.out.println("Ignition");
	}
	
}