class Duplicate{
	public static void main(String...args){
		String input="ABCDEFGHIJK";
		for(int i = 0 ; i < input.length(); i++){
			
				int count=0;
				
				for(int j = 0; j < input.length(); j++){z
					if(input.charAt(i) == input.charAt(j)){
							count++;
	}
}