/*1.How to Print duplicate characters from String?
2. How to reverse words in a sentence without using library method? (solution)
Hint :Write a function, which takes a String word and return sentence on which
words are reversed in order e.g. if input is "Java is best programming language", output
 should be "language programming best is Java".*/

import java.util.*;

class CountDuplicate{
	public static void main(String [] args ){
		String input = "STRINGG";
		
		for(int i = 0 ; i < input.length(); i++){
			
				int count=0;
				
				for(int j = 0; j < input.length(); j++){z
					if(input.charAt(i) == input.charAt(j)){
							count++;	
								
					}
					if(count > 1){
						System.out.println(input.charAt(i)+" "+ (count));
					}
				}
					
			
		}

	}
}